//===============================================================================
//        Добаивить @ перед командой prepros-append (// убирать не нужно)
//===============================================================================

$(function () {
  //_let.js - глобальные переменные, базовые функции
  //  Содержит:
  //              функции определения бюраузера и мобильных устройств
  //              проверка поддержки формата webp
  //              контроль окончания загрузки страницы
  //              функции блокировки body
  //              функцию ibg (работа с фоновыми изображениями)
  //              функция перехода _goto
  //  Зависимости:
  //              требуется подключенный _ibg.scss
  //              требуется подключенный lib/smooth-scroll.polyfills.min.js (для переходов)
  //!!! ПОДКЛЮЧЕН
  //@prepros-append scripts/_let.js
  //=============================================================================
  //_header.js - функционал для заголовка (бургер, переходы по пунктам меню)
  //  Содержит:
  //              функции работы с бургер-меню
  //              функция фиксации блока при прокрутке
  //              функции перехода к блоку (из меню)
  //  Зависимости:
  //              требуется подключенный _let.js
  //              требуется подключенный _popup.js
  //!!! ПОДКЛЮЧЕН
  //@prepros-append scripts/_header.js
  //=============================================================================
  //_responsive.js - функции адаптива (перенос содержимого при адаптиве)
  //  Содержит:
  //              функцию Dynamic Adapt v.1
  //              функцию "ручного" переноса
  //prepros-append scripts/_responsive.js
  //===============================================================================
  //_sliders.js - инициализация слайдеров
  //@prepros-append scripts/_sliders.js
  //===============================================================================
  //_widgets.js - функционал виджетов
  //prepros-append scripts/_widgets.js
  //===============================================================================
  //_popup.js - работа с popup-окнами
  //              обработчик # параметра в строке адреса
  //  Зависимости:
  //              требуется подключенный scripts/_let.js
  //              требуется подключенный _popup.scss
  //!!! ПОДКЛЮЧЕН
  //@prepros-append scripts/_popup.js
  //=============================================================================
  //_map-google.js - для google карт
  //!!! Требует jQuery
  //prepros-append scripts/_map-google.js
  //===============================================================================
  //_map-yandex.js - для yandex карт
  //!!! Требует jQuery
  //prepros-append scripts/_map-yandex.js
  //===============================================================================
  // !!! СЮДА ПИШЕМ СКРИПТЫ
  //@prepros-append script.js
  //===============================================================================
  //Еще не разобраны
  //prepros-append scripts/forms.js
  //prepros-append scripts/fullscroll.js
  //repros-append scripts/script.js
  //repros-append scripts/scroll.js
});

//===============================================================================
//        Глобальные переменные
//===============================================================================
//Для чего переменные w и h - пока не известно. Переменные используются в разных скриптах,
//но вот нужна ли их инициализация - я не знаю. Пока оставил, а оптом уже буду смотреть
//влияют они на что-то или нет
//let w = $(window).outerWidth();
//let h = $(window).outerHeight();
//===============================================================================
// Тег body
const body = document.querySelector("body");
//===============================================================================
//        Переменные для бургер-меню
//===============================================================================
// Длительность анимации при работе бургер-меню
const timeoutBurger = 300;
// Иконка бургера
const iconMenu = document.querySelector(".icon-menu");
// Меню (скрываемое / показываемое)
const menuBody = document.querySelector(".menu__body");
//===============================================================================
//        Переменные для popup-окон
//===============================================================================
// Набор ссылок, для открытия popup-окон
const popupLinks = document.querySelectorAll("._popup-link");
// Набор фиксированных элементов, которым необходимо применять psdding при блокировке body
const lockPadding = document.querySelectorAll("._lock-padding");
// Длительность анамации при работе с popup-окнами
const timeoutPopup = 800;

//===============================================================================
//        Определение браузера IE и устройств (мобильное или нет)
//===============================================================================
let ua = window.navigator.userAgent;
let msie = ua.indexOf("MSIE ");
let isMobile = {
  Android: function () {
    return navigator.userAgent.match(/Android/i);
  },
  BlackBerry: function () {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  iOS: function () {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  Opera: function () {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  Windows: function () {
    return navigator.userAgent.match(/IEMobile/i);
  },
  any: function () {
    return isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows();
  },
};

function isIE() {
  ua = navigator.userAgent;
  let is_ie = ua.indexOf("MSIE ") > -1 || ua.indexOf("Trident/") > -1;
  return is_ie;
}

// для браузера IE тегу body добавляется класс _ie
if (isIE()) {
  $("body").addClass("_ie");
}

// для мобильных устройств тегу body добавляется класс _touch
if (isMobile.any()) {
  $("body").addClass("_touch");
}

//===============================================================================
//        Проверка на поддержку webp
//===============================================================================
function testWebP(callback) {
  let webP = new Image();
  webP.onload = webP.onerror = function () {
    callback(webP.height == 2);
  };
  webP.src = "data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACyAgCdASoCAAIALmk0mk0iIiIiIgBoSygABc6WWgAA/veff/0PP8bA//LwYAAA";
}

// в случае поддержки брауззером формата webp, тегу body добавляется класс _webp
testWebP(function (support) {
  if (support == true) {
    document.querySelector("body").classList.add("_webp");
  }
});

//===============================================================================
//        Завершение загрузки страницы
//===============================================================================
// после полной загрузки страницы элементу добавляет класс _loaded
if (document.querySelector(".wrapper")) {
  document.querySelector(".wrapper").classList.add("_loaded");
}

//===============================================================================
//        Функция ibg (работа с фоновыми изображениями)
//===============================================================================
// Старая версия функции, работающая для всех изображений с классом ibg
/*function ibg() {
  $.each($(".ibg"), function(index, val) {
    if ($(this).find("img").length > 0) {
      $(this).css("background-image", 'url("' + $(this).find("img").attr("src") +'")');
    }
  });
}*/
// Новая версия, ориентированная только для браузера IE (для остальных используется свойство object-fit)
function ibg() {
  if (isIE()) {
    let _ibg = document.querySelectorAll("._ibg");
    for (let i = 0; i < _ibg.length; i++) {
      if (_ibg[i].querySelector("img") && _ibg[i].querySelector("img").getAttribute("src") != null) {
        _ibg[i].style.backgroundImage = "url(" + _ibg[i].querySelector("img").getAttribute("src") + ")";
      }
    }
  }
}
// Вызов функции
ibg();

//===============================================================================
//        Функция блокировки / разблокировки дейтсвий пользователя
//===============================================================================
// Функция для бургер-меню (триггер) для функций bodyLock и bodyUnLock
function bodyLockToggle(delay) {
  if (body.classList.contains("_lock")) {
    bodyUnLock(delay);
  } else {
    bodyLock(delay);
  }
}

// Функция блокирующая body
function bodyLock(delay) {
  if (!body.classList.contains("_wait")) {
    // вычисляем ширину скролла
    const lockPaddingValue = window.innerWidth - document.querySelector(".wrapper").offsetWidth + "px";

    if (lockPadding.length > 0) {
      // пробегаем по всем элементам с классом _lock-padding и задаем свойство padding-right,
      // равное ширине скролла
      for (let index = 0; index < lockPadding.length; index++) {
        const el = lockPadding[index];
        el.style.paddingRight = lockPaddingValue;
      }
    }
    // это же значение присваиваем и для body
    body.style.paddingRight = lockPaddingValue;
    body.classList.add("_lock");
    // выставляем режим ожидания...
    body.classList.add("_wait");
    // и по истечении timeout'а снимаем его
    setTimeout(function () {
      body.classList.remove("_wait");
    }, delay);
  }
}

// Функция разблокирующая body
function bodyUnLock(delay) {
  if (!body.classList.contains("_wait")) {
    // по истечении timeout'а убираем padding-right у всех элементов и снимаем блокировку
    setTimeout(function () {
      if (lockPadding.length > 0) {
        for (let index = 0; index < lockPadding.length; index++) {
          const el = lockPadding[index];
          el.style.paddingRight = "0px";
        }
      }
      body.style.paddingRight = "0px";
      body.classList.remove("_lock");
    }, delay);
    //! закоментировал - мне кажется эта задержка не нужна
    // выставляем режим ожидания...
    //body.classList.add("_wait");
    // и по истечении timeout'а снимаем его
    //setTimeout(function () {
    //  body.classList.remove("_wait");
    //}, delay);
  }
}

//===============================================================================
//        Функция перехода
//===============================================================================
function _goto(target_block, speed) {
  // let offset = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
  // возможно нужно переделать, чтобы высота определялась средствами js
  let header = 48; //OffsetHeader
  // if (window.innerWidth < 992) {
  //   header = 30;
  // }
  window.scroll({ top: target_block.offsetTop - header, left: 0, behavior: "smooth" });

}

//===============================================================================
//        Бургер меню
//===============================================================================
// вешаем обработчик на бургер
if (iconMenu != null) {
  iconMenu.addEventListener("click", function (e) {
    if (!body.classList.contains("_wait")) {
      bodyLockToggle(timeoutBurger);
      iconMenu.classList.toggle("_active");
      menuBody.classList.toggle("_active");
    }
  });
}

// Функция,закрывающее бургер-меню
function menuСlose() {
  iconMenu.classList.remove("_active");
  menuBody.classList.remove("_active");
}

//===============================================================================
//        Обработчки закрытия выпадающего меню или бургера (верстка LuxTrade)
//===============================================================================
// селектор блока пользовательского меню (родитель тела)
let areaMenu = ".user-header";
// тело пользовательского меню (выпадающая его часть)
let userMenu = document.querySelector(".user-header__menu");
// закрытие пользовательского меню по клику вне его
if (userMenu != null) {
  document.documentElement.addEventListener("click", function (e) {
    // если click произошел вне пользовательского меню...
    if (!e.target.closest(areaMenu)) {
      // закрываем пользовательское меню
      userMenu.classList.remove("_active");
    } else {
      // если же кликнули по пользовательскому меню (чтобы его открыть)...
      // проверяем, а открыт ли бургер...
      if (iconMenu.classList.contains("_active")) {
        // если открыт, то закрываем его
        menuСlose();
      }
    }
  });
}

//===============================================================================
//        Фиксация блока при прокрутке (при достижении определенной высоты) (верстка Cappadocia)
//===============================================================================
// Для фиксируемого блока задаётся класс _fixed

// блок, который фиксируем
let fixedBlock = document.querySelector(".menu");
// по достижении высоты какого блока фиксируем
let startOffset = document.querySelector(".header").offsetHeight;
// тукущее значение скролла
let scrollOffset = window.pageYOffset;
// дополнительное смещение (если нужно зафиксировать чуть раньше)
let addOffset = 0;

function checkScroll(scrollOffset) {
  if (scrollOffset >= startOffset - addOffset) {
    fixedBlock.classList.add("_fixed");
  } else {
    fixedBlock.classList.remove("_fixed");
  }
}

// вызов функции при скролле
window.addEventListener("scroll", function () {
  scrollOffset = window.pageYOffset;
  // обновляем startOffset, иначе при повороте девайса пропадает _fixed
  startOffset = document.querySelector(".header").offsetHeight;
  checkScroll(scrollOffset);
});

checkScroll(scrollOffset);

//===============================================================================
//        Переход из меню к блокам с подсветкой пунктов меню (верстка LuxTrade)
//===============================================================================
// ссылке добавляется класс _goto-block
// в аттрибуте href указывается #класс_блока к которому нужно перейти
// в стилях у ссылки должен быть прописан класс _active
let link = document.querySelectorAll("._goto-block");

if (link) {
  let blocks = [];

  // !!! Функция-выражение не обрабатывается до тех пор, пока интерпретатор не дойдет
  // до инструкции, в которой она содержится. Следовательно, нельзя вызвать такую
  // функцию прежде, чем интерпретатор ее обнаружит. Кроме того, это означает, что
  // любой код, выполнявшийся до функциивыражения, потенциально может изменить
  // осуществляемые в ней операции.
  let _loop7 = function _loop7(_index28) {
    let el = link[_index28];
    let block_name = el.getAttribute("href").replace("#", "");

    if (block_name != "" && !~blocks.indexOf(block_name)) {
      blocks.push(block_name);
    }

    el.addEventListener("click", function (e) {
      // !!! ВАЖНО
      // моя переделка, проверить при следующем использовании
      if (menuBody.classList.contains("_active")) {
        menuClose();
        bodyUnLock(timeoutBurger);
      }
      /*if (document.querySelector(".menu__body._active")) {
        menuClose();
        bodyUnLock(500);
      }*/

      let target_block_class = el.getAttribute("href").replace("#", "");
      let target_block = document.querySelector("." + target_block_class);

      _goto(target_block, 300);

      e.preventDefault();
    });
  };

  for (let _index28 = 0; _index28 < link.length; _index28++) {
    _loop7(_index28);
  }

  window.addEventListener("scroll", function (el) {
    let old_current_link = document.querySelectorAll("._goto-block._active");

    if (old_current_link) {
      for (let _index29 = 0; _index29 < old_current_link.length; _index29++) {
        let _el13 = old_current_link[_index29];

        _el13.classList.remove("_active");
      }
    }

    for (let _index30 = 0; _index30 < blocks.length; _index30++) {
      let block = blocks[_index30];
      let block_item = document.querySelector("." + block);

      if (block_item) {
        let block_offset = offset(block_item).top;
        let block_height = block_item.offsetHeight;

        // window.innerHeight / 3 можно заменять на значение в пикселях, дабы компенсировать фиксированную шапку
        // вообще window.innerHeight / 3 позволяет присваивать класс немного раньше, пока блок не достиг верхней точки
        if (pageYOffset > block_offset - window.innerHeight / 3 && pageYOffset < block_offset + block_height - window.innerHeight / 3) {
          let current_links = document.querySelectorAll('._goto-block[href="#' + block + '"]');

          for (let _index31 = 0; _index31 < current_links.length; _index31++) {
            let current_link = current_links[_index31];
            current_link.classList.add("_active");
          }
        }
      }
    }
  });
}

// Вспомогательная функция (используется в переходах с подсветкой пункта меню)
function offset(el) {
  let rect = el.getBoundingClientRect(),
    scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
    scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  return {
    top: rect.top + scrollTop,
    left: rect.left + scrollLeft,
  };
}

//===============================================================================
//        Переход из меню к блокам
//===============================================================================
// ссылке добавляется класс _goto-block
// в аттрибуте href указывается #класс_блока к которому нужно перейти
let goto_links = document.querySelectorAll("._goto");

if (goto_links) {
  let _loop8 = function _loop8(_index32) {
    let goto_link = goto_links[_index32];
    goto_link.addEventListener("click", function (e) {
      let target_block_class = goto_link.getAttribute("href").replace("#", "");
      let target_block = document.querySelector("." + target_block_class);

      // !!! ВАЖНО
      // моя переделка, проверить при следующем использовании
      if (menuBody.classList.contains("_active")) {
        menuСlose();
        bodyUnLock(timeoutBurger);
      }
      /*if (document.querySelector(".menu__body._active")) {
        menuClose();
        bodyUnLock(500);
      }*/

      _goto(target_block, 300);

      e.preventDefault();
    });
  };

  for (let _index32 = 0; _index32 < goto_links.length; _index32++) {
    _loop8(_index32);
  }
}

if ($(".photo__slider").length > 0) {
  $(".photo__slider").slick({
    centerMode: true,
    centerPadding: "0px",
    slidesToShow: 1,
    initialSlide: 1,
    speed: 500,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          autoplay: true,
          autoplaySpeed: 5000,
          arrows: false,
          dots: true,
        },
      },
    ],
  });
}

//=============================================================================
// Базовый скрипт для слайдера
/*
if ($(".class").length > 0) {
  $(".class").slick({

  });
}
*/
//=============================================================================
// Параметры:
//   accessibility (Type: boolean, Default: true) - доступность слайдера с
//        клавиатуры (по Tab)
//   adaptiveHeight (Type: boolean, Default: false) - слайдер будет подсраиваться
//        высоте под каждый конкретный слайд. Для этого в стилях для слайдера
//        необходимо задать align-items: flex-start;
//   appendArrows (Type: string, Default: $(element)) - указывается селектор,
//        внутри которого будут размещены стрелки
//   appendDots (Type: string, Default: $(element)) - указывается селектор,
//        внутри которого будут размещены точки
//   arrows (Type: boolean, Default: true) - показывать / скрывать стрелки
//   prevArrow (Type: string) - jQuery-селектор или html разметка для кнокпи
//        "Предыдущий слайд"
//   nextArrow (Type: string) - jQuery-селектор или html разметка для кнокпи
//        "Следующий слайд"
//   asNavFor (Type: string, Default: null) - позволяет связать два слайдера
//        (этот параметр указывается для обоих слайдеров)
//   autoplay (Type: boolean, Default: false) - автоматическая смена слайдов
//   autoplaySpeed (Type: int, Default: 3000) - скорость (в ms) смены слайдов
//   centerMode (Type: boolean, Default: false) - располагает активный слайд по
//        центру слайдера, при этом слайду добавляется класс .slick-center
//   dots (Type: boolean, Default: false) - показывать / скрывать точки
//   draggable (Type: boolean, Default: true) - возможность менять слайды с
//        помощью мыши (на ПК)
//   easing (Type: string, Default: "linear") - задает тип анимации
//   fade (Type: boolean, Default: false) - вариант смены слайдов с затуханием
//   infinite (Type: boolean, Default: true) - возможнось бесконечной прокрутки
//   initialSlide (Type: int, Default: 0) - стартовый слайд
//   mobileFirst (Type: boolean, Default: false) - mobile ferst для парметра
//        responsive
//   pauseOnFocus (Type: boolean, Default: true) - отключения смены слайдов при
//        фокусе
//   pauseOnHover (Type: boolean, Default: true) - отключения смены слайдов при
//        наведении
//   pauseOnDotsHover (Type: boolean, Default: true) - отключения смены слайдов
//        при наведении на точки
//   responsive (Type: object, Default: none) - позволяет менять параметры
//        сладйера в зависимости от разрешения экрана. Формат записи:
//             responsive: [
//               {
//                 breakpoint: 1024,
//                 settings: {
//                   параметр: значение,
//                   ...
//                 }
//               },
//               {
//                 breakpoint: 600,
//                 settings: {
//                   ...
//               }
//             ]
//   rows (Type: int, Default: 1) - количество рядов со слайдами
//   slidesPerRow (Type: int, Default: 1) - количество слайдов в ряду
//   slidesToShow (Type: int, Default: 1) - количество отображаемых слайдов
//   slidesToScroll (Type: int, Default: 1) - количество пролистываемых слайдов
//   speed (Type: int, Default: 300) - скорость (в ms) пролистывания слайдов
//   swipe (Type: boolean, Default: true) - возможность менять слайды (свайпать)
//        на touch-screen
//   touchMove (Type: boolean, Default: true) - отображение движения слайдов при
//        свайпе
//   touchThreshold (Type: int, Default: 5) - расстояние, которое нужно провести
//        при свайпе для смены слайдов. Вычисляется по формуле:
//        (1 / touchThreshold) * ширина слайдера
//   variableWidth (Type: boolean, Default: false) - даёт возможность слайдам
//        изменять свою ширину (согласно контента). В этом случае свойство
//        slidesToShow не действует. Можно использовать, если требуется сделать
//        автоматический адаптивный слайдер. Хорошо работает с centerMode
//   vertical (Type: boolean, Default: false) - режим вертикального слайдера.
//        В этом слуйчае у слайдера требуется убрать display: flex. Не корректно
//        работает со слайдами разной высоту, поэтому необходимо для слайдов
//        задать фиксированную высоту
//   verticalSwiping (Type: boolean, Default: false) - режим вертикального свайпа
//   waitForAnimate (Type: boolean, Default: true) - ожидать завершения анимации
//        перед тем, как начать какое-либо действие на слайдером
//   zIndex (Type: int, Default: 1000) - z-index слайдера
//=============================================================================
// События:
/*
$('.slider').on('beforeChange', function(event, slick, currentSlide, nextSlide){
  console.log(nextSlide);
}

$('.slider').on('afterChange', function(event, slick, currentSlide){
  console.log(currentSlide);
}
*/
//=============================================================================
// Методы:
//   $('.slider').slick('метод', аргумент);
//   setPosition (аргументов нет) - пересчет координат и размеров слайдера
//   slickGoTo (int: номер слайда, boolean: не анимировать) - переход к
//       определенному слайду (номерация слайдов идет с 0)
//   slickPrev (аргументов нет) - переход к предыдущему слайду
//   slickNext (аргументов нет) - переход к следующему слайду
//   slickPlay (аргументов нет) - включает автопрокрутку слайдов
//   slickPause (аргументов нет) - остановить автопрокрутку слайдов
//   unslick (аргументов нет) - отключает слайдер

//===============================================================================
//        Обработка # параметра в строке адреса
//===============================================================================
if (location.hash) {
  let hsh = location.hash.replace("#", "");
  // если есть такой popup...
  if (document.querySelector("._popup-" + hsh)) {
    // то открываем его
    popupOpen(document.querySelector("._popup-" + hsh));
    // если div с таким классом, то переходим к нему
  } else if (document.querySelector("div." + hsh)) {
    _goto(document.querySelector("." + hsh), 500);
  }
}

//===============================================================================
//        Обработчики на все ссылки для открытия popup-окон
//===============================================================================
if (popupLinks.length > 0) {
  for (let index = 0; index < popupLinks.length; index++) {
    const popupLink = popupLinks[index];
    popupLink.addEventListener("click", function (e) {
      const popupName = popupLink.getAttribute("href").replace("#", "");
      const videoLink = popupLink.getAttribute("data-vid");
      // поиск popup по id
      //const curentPopup = document.getElementById(popupName);
      // поиск popup по class
      const curentPopup = document.querySelector("._popup-" + popupName);
      popupOpen(curentPopup, videoLink);
      e.preventDefault();
    });
  }
}

//===============================================================================
//        Обработчики на все кнопки закрытия попуп (элемент с классом close-popup)
//===============================================================================
const popupCloseIcon = document.querySelectorAll("._close-popup");
if (popupCloseIcon.length > 0) {
  for (let index = 0; index < popupCloseIcon.length; index++) {
    const el = popupCloseIcon[index];
    el.addEventListener("click", function (e) {
      popupClose(el.closest(".popup"));
      e.preventDefault();
    });
  }
}

//===============================================================================
//        Открытие popup-окна
//===============================================================================
function popupOpen(curentPopup, videoLink) {
  if (curentPopup && !body.classList.contains("_wait")) {
    const popupActive = document.querySelector(".popup._open");
    // если из одного popup-окна пытаем открыть другое...
    if (popupActive) {
      // то первое закрываем, не разблокируя при этом body (за это отвечает второй параметр)
      popupClose(popupActive, false);
    } else {
      // иначе, блокироуем body
      bodyLock(timeoutPopup);
    }
    // видео в popup
    if (videoLink != "" && videoLink != null) {
      let iframe = document.createElement("iframe");
      const divVideo = curentPopup.querySelector(".popup__video");
      iframe.src = "https://www.youtube.com/embed/" + videoLink + "?autoplay=1";
      iframe.allow = "autoplay; encrypted-media";
      iframe.allowFullscreen = "allowfullscreen";
      divVideo.appendChild(iframe);
    }

    // закрываем бургер меню, перед открытием попапа
    if (iconMenu.classList.contains("_active")) {
      // если открыт, то закрываем его
      menuСlose();
    }

    // открываем окно
    curentPopup.classList.add("_open");
    // вешаем обработчик, который закроет popup-окно, при клике за его пределами
    curentPopup.addEventListener("click", function (e) {
      if (!e.target.closest(".popup__content")) {
        popupClose(e.target.closest(".popup"));
      }
    });
  }
}

//===============================================================================
//        Закрытие popup-окна
//===============================================================================
// такой вариант не работает в IE
//function popupClose(popupActive, doUnlock = true) {
function popupClose(popupActive, doUnlock) {
  // для IE (инициализация переменной)
  doUnlock = doUnlock || true;

  if (!body.classList.contains("_wait")) {
    popupActive.classList.remove("_open");
    if (!body.classList.contains("_wait")) {
      bodyUnLock(timeoutPopup);

      // очисщаем видео
      const divVideo = popupActive.querySelector(".popup__video");
      if (divVideo) {
        divVideo.innerHTML = "";
      }
    }
  }
}

//===============================================================================
//        Закрытие popup-окна по ESC
//===============================================================================
document.addEventListener("keydown", function (e) {
  if (e.which === 27) {
    const popupActive = document.querySelector(".popup._open");
    popupClose(popupActive);
  }
});

//===============================================================================
//        Полифил для JS-функций со слабой поддержкой в браузерах
//===============================================================================
(function () {
  // проверяем поддержку
  if (!Element.prototype.closest) {
    // реализуем
    Element.prototype.closest = function (css) {
      var node = this;
      while (node) {
        if (node.matches(css)) return node;
        else node = node.parentElement;
      }
      return null;
    };
  }
})();
(function () {
  // проверяем поддержку
  if (!Element.prototype.matches) {
    // определяем свойство
    Element.prototype.matches =
      Element.prototype.matchesSelector || Element.prototype.webkitMatchesSelector || Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector;
  }
})();

//===============================================================================
//        Вариант работы с popup на JQuery
//===============================================================================
/*$(".pl").click(function (event) {
  var pl = $(this).attr("href").replace("#", "");
  var v = $(this).data("vid");
  popupOpen(pl, v);
  return false;
});

function popupOpen(pl, v) {
  $(".popup").removeClass("active").hide();
  if (!$(".header-menu").hasClass("active")) {
    $("body").data("scroll", $(window).scrollTop());
  }
  if (!isMobile.any()) {
    $("body")
      .css({ paddingRight: $(window).outerWidth() - $(".wrapper").outerWidth() })
      .addClass("lock");
    $(".pdb").css({ paddingRight: $(window).outerWidth() - $(".wrapper").outerWidth() });
  } else {
    setTimeout(function () {
      $("body").addClass("lock");
    }, 300);
  }
  history.pushState("", "", "#" + pl);
  if (v != "" && v != null) {
    $(".popup-" + pl + " .popup-video__value").html(
      '<iframe src="https://www.youtube.com/embed/' + v + '?autoplay=1"  allow="autoplay; encrypted-media" allowfullscreen></iframe>'
    );
  }
  $(".popup-" + pl)
    .fadeIn(300)
    .delay(300)
    .addClass("active");

  if ($(".popup-" + pl).find(".slick-slider").length > 0) {
    $(".popup-" + pl)
      .find(".slick-slider")
      .slick("setPosition");
  }
}

function openPopupById(popup_id) {
  $("#" + popup_id)
    .fadeIn(300)
    .delay(300)
    .addClass("active");
}

function popupClose() {
  $(".popup").removeClass("active").fadeOut(300);
  if (!$(".header-menu").hasClass("active")) {
    if (!isMobile.any()) {
      setTimeout(function () {
        $("body").css({ paddingRight: 0 });
        $(".pdb").css({ paddingRight: 0 });
      }, 200);
      setTimeout(function () {
        $("body").removeClass("lock");
        $("body,html").scrollTop(parseInt($("body").data("scroll")));
      }, 200);
    } else {
      $("body").removeClass("lock");
      $("body,html").scrollTop(parseInt($("body").data("scroll")));
    }
  }
  $(".popup-video__value").html("");

  history.pushState("", "", window.location.href.split("#")[0]);
}

$(".popup-close,.popup__close").click(function (event) {
  popupClose();
  return false;
});

$(".popup").click(function (e) {
  if (!$(e.target).is(".popup>.popup-table>.cell *") || $(e.target).is(".popup-close") || $(e.target).is(".popup__close")) {
    popupClose();
    return false;
  }
});

$(document).on("keydown", function (e) {
  if (e.which == 27) {
    popupClose();
  }
});*/

//=============================================================================
// Делаем картинки в блоках-карточках квадратными
// для работы необходимо при объявлении пекременной list указать классы оболочеек картинок
function resizeImage() {
  let list = document.querySelectorAll(".card__image, .about__people");
  Array.prototype.forEach.call(list, function (item) {
    item.style.height = item.offsetWidth + "px";
  });
}

window.addEventListener("resize", resizeImage);

resizeImage();

/// СПОЙЛЕР НА JAVASCRIPT

// $(".footer__title").click(function (event) {
//   $(this).toggleClass("active").next().slideToggle(300);
// });
const spoller = document.querySelectorAll(".footer__title");
for (let i = 0; i < spoller.length; i++) {
  spoller[i].addEventListener("click", (event) => {
    if (Math.max(document.documentElement.clientWidth, window.innerWidth || 0) <= 480) {
      var targ = event.target;
      if (targ.classList.contains("active")) {
        hideAll();
      } else {
        hideAll();
        targ.classList.add("active");
        targ.nextElementSibling.style.height = targ.nextElementSibling.scrollHeight + "px";
        //showText();
      }
    }
  });
}

function hideAll() {
  let h3El = document.querySelectorAll(".footer__title");
  let divEl = document.querySelectorAll(".footer__list");
  for (let i = 0; i < h3El.length; i++) {
    h3El[i].classList.remove("active");
  }
  for (var i = 0; i < divEl.length; i++) {
    divEl[i].style.height = "0";
  }
}

// function showText(textEl) {
//   textEl.style.height = textEl.scrollHeight + "px";
// }

